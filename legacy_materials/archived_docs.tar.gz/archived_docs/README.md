This directory contains archived documents that have nothing to do with the
main software documentation. These documents are kept for historical purpose.
