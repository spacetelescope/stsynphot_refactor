References
==========

.. _ref1:

1. Synphot Manual: http://stsdas.stsci.edu/stsci_python_epydoc/SynphotManual.pdf

.. _ref2:

2. Schneider, Gunn and Hoessel (1983 ApJ 264,337)

.. _ref3:

3. Koornneef et al., 1987

.. _ref4:

4. WFPC1 Instrument Handbook:
   http://www.stsci.edu/hst/wfpc/documents/HST_WFPC_Instrument_Handbook.pdf

.. _ref5:

5. WFPC2 Instrument Handbook:
   http://www.stsci.edu/instruments/wfpc2/Wfpc2_hand_current/wfpc2_ihb.pdf
