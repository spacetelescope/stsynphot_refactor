.. TSR 2011-4: Comparison of Synphot and Pysynphot Bandpar Functionality master file, created by
   sphinx-quickstart on Tue Mar 30 11:09:55 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

TSR 2011-4: Comparison of Synphot and Pysynphot Bandpar Functionality
=====================================================================

Contents:

.. toctree::
   :maxdepth: 2
   
   main.rst
   references.rst
